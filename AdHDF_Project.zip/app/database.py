import sqlite3
import json
from pathlib import Path
from collections import Counter

DB_PATH = Path("adhdf_enterprise.db")

def init_db():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS incidents (
            id TEXT PRIMARY KEY,
            timestamp TEXT NOT NULL,
            event_type TEXT NOT NULL,
            severity TEXT NOT NULL,
            risk_score INTEGER NOT NULL,
            total_hits_from_ip INTEGER NOT NULL,
            canary_id TEXT NOT NULL,
            attacker_ip TEXT NOT NULL,
            target_path TEXT NOT NULL,
            detected_tool TEXT NOT NULL,
            confidence TEXT NOT NULL,
            http_fp_hash TEXT NOT NULL,
            header_sequence TEXT,
            user_agent TEXT,
            payload TEXT,
            served_response TEXT
        )
    """)
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_attacker_ip ON incidents(attacker_ip)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_risk_score ON incidents(risk_score)")
    conn.commit()
    conn.close()

def insert_incident(entry: dict):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO incidents (
            id, timestamp, event_type, severity, risk_score, total_hits_from_ip,
            canary_id, attacker_ip, target_path, detected_tool, confidence,
            http_fp_hash, header_sequence, user_agent, payload, served_response
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        entry["id"], entry["timestamp"], entry["event_type"], entry["severity"],
        entry["risk_score"], entry["total_hits_from_ip"], entry["canary_id"],
        entry["attacker_ip"], entry["target_path"], entry["detected_tool"],
        entry["confidence"], entry["http_fp_hash"], entry["header_sequence"],
        entry["user_agent"], entry["payload"], entry["served_response"]
    ))
    conn.commit()
    conn.close()

def get_dashboard_metrics() -> dict:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) FROM incidents")
    total_events = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM incidents WHERE event_type = 'CRITICAL_CANARY_TRIGGERED'")
    canary_triggers = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(DISTINCT attacker_ip) FROM incidents")
    unique_ips = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(DISTINCT attacker_ip) FROM incidents WHERE risk_score >= 80")
    critical_actors = cursor.fetchone()[0]

    cursor.execute("SELECT event_type, COUNT(*) as cnt FROM incidents GROUP BY event_type")
    attack_dist = {row["event_type"]: row["cnt"] for row in cursor.fetchall()}

    cursor.execute("SELECT detected_tool, COUNT(*) as cnt FROM incidents GROUP BY detected_tool")
    tool_dist = {row["detected_tool"]: row["cnt"] for row in cursor.fetchall()}

    cursor.execute("SELECT * FROM incidents ORDER BY timestamp DESC LIMIT 50")
    recent_events = [dict(row) for row in cursor.fetchall()]

    conn.close()
    return {
        "total_events": total_events,
        "canary_triggers": canary_triggers,
        "unique_ips": unique_ips,
        "critical_actors": critical_actors,
        "attack_distribution": attack_dist,
        "tool_distribution": tool_dist,
        "recent_events": recent_events
    }

def get_all_incidents() -> list:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM incidents ORDER BY timestamp DESC")
    rows = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return rows

def get_malicious_blocklist(min_score: int = 80) -> list:
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("""
        SELECT DISTINCT attacker_ip, MAX(risk_score), MAX(timestamp)
        FROM incidents
        WHERE risk_score >= ?
        GROUP BY attacker_ip
    """, (min_score,))
    results = [{"ip": r[0], "max_risk_score": r[1], "last_seen": r[2]} for r in cursor.fetchall()]
    conn.close()
    return results
