import os
import json
import time
import urllib.request
import asyncio
from fastapi import Request

IP_RISK_PROFILES = {}
FAILED_AUTH_ATTEMPTS = {}  # {ip: {"count": int, "locked_until": float}}

def get_real_attacker_ip(request: Request) -> str:
    """Yalnızca güvenilir proxy arkasından geliyorsa X-Forwarded-For başlığına güvenir (IP Spoofing koruması)."""
    direct_ip = request.client.host if request.client else "0.0.0.0"
    trusted_proxies = [x.strip() for x in os.getenv("TRUSTED_PROXY_IPS", "127.0.0.1").split(",") if x.strip()]
    
    if direct_ip in trusted_proxies:
        forwarded = request.headers.get("x-forwarded-for")
        if forwarded:
            return forwarded.split(",")[0].strip()
        real_ip = request.headers.get("x-real-ip")
        if real_ip:
            return real_ip.strip()
            
    return direct_ip

def check_auth_lockout(ip: str) -> bool:
    """SOC girişinde 5 hatalı deneme yapan IP'yi 15 dakika kilitler."""
    record = FAILED_AUTH_ATTEMPTS.get(ip)
    if not record:
        return False
    if time.time() < record["locked_until"]:
        return True
    if time.time() >= record["locked_until"] and record["count"] >= 5:
        del FAILED_AUTH_ATTEMPTS[ip]
    return False

def register_failed_auth(ip: str):
    record = FAILED_AUTH_ATTEMPTS.get(ip, {"count": 0, "locked_until": 0})
    record["count"] += 1
    if record["count"] >= 5:
        record["locked_until"] = time.time() + 900  # 15 dakika kilit
    FAILED_AUTH_ATTEMPTS[ip] = record

def clear_failed_auth(ip: str):
    if ip in FAILED_AUTH_ATTEMPTS:
        del FAILED_AUTH_ATTEMPTS[ip]

def is_ip_whitelisted(ip: str) -> bool:
    whitelist = [x.strip() for x in os.getenv("WHITELIST_IPS", "").split(",") if x.strip()]
    return ip in whitelist

def is_ip_blocked(ip: str) -> bool:
    if is_ip_whitelisted(ip):
        return False
    if os.getenv("ACTIVE_BLOCK_ENABLED", "true").lower() != "true":
        return False
    threshold = int(os.getenv("BLOCK_THRESHOLD", "75"))
    profile = IP_RISK_PROFILES.get(ip)
    return bool(profile and profile["score"] >= threshold)

def calculate_threat_score(ip: str, event_type: str, confidence: str) -> dict:
    profile = IP_RISK_PROFILES.get(ip, {"score": 0, "hits": 0, "canary_triggered": False})
    profile["hits"] += 1

    weight_map = {
        "Directory Fuzzing / Recon": 15,
        "Sensitive File Exposure": 35,
        "Path Traversal / LFI": 45,
        "SQL Injection": 50,
        "CRITICAL_CANARY_TRIGGERED": 100
    }
    added_score = weight_map.get(event_type, 10)
    if confidence == "High":
        added_score += 10

    if event_type == "CRITICAL_CANARY_TRIGGERED":
        profile["score"] = 100
        profile["canary_triggered"] = True
    else:
        profile["score"] = min(95, profile["score"] + added_score)

    IP_RISK_PROFILES[ip] = profile

    severity = "LOW"
    if profile["score"] >= 80:
        severity = "CRITICAL"
    elif profile["score"] >= 50:
        severity = "HIGH"
    elif profile["score"] >= 25:
        severity = "MEDIUM"

    return {
        "risk_score": profile["score"],
        "severity": severity,
        "total_hits_from_ip": profile["hits"]
    }

async def dispatch_webhook_alert(event_data: dict):
    webhook_url = os.getenv("ALERT_WEBHOOK_URL", "").strip()
    if not webhook_url or not webhook_url.startswith("https://"):
        return

    payload = {
        "content": (
            f"🚨 **[AdHDF SOC ALERT - {event_data['severity']}]**\n"
            f"**Olay:** `{event_data['event_type']}` | **Risk Skoru:** `{event_data['risk_score']}/100`\n"
            f"**Saldırgan IP:** `{event_data['attacker_ip']}` | **Araç:** `{event_data['detected_tool']}`\n"
            f"**Hedef:** `{event_data['target_path']}` | **Canary ID:** `{event_data['canary_id']}`"
        )
    }

    def _send():
        try:
            req = urllib.request.Request(
                webhook_url,
                data=json.dumps(payload).encode("utf-8"),
                headers={"Content-Type": "application/json", "User-Agent": "AdHDF-SOC-Notifier/1.0"}
            )
            urllib.request.urlopen(req, timeout=4)
        except Exception:
            pass

    await asyncio.to_thread(_send)
